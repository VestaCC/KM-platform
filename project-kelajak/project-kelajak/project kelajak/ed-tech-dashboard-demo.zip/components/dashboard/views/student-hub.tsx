import {
  Award,
  Trophy,
  GraduationCap,
  Quote,
  TrendingUp,
  HeartHandshake,
  Cpu,
  Medal,
  Mic,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ProgressRing } from '@/components/dashboard/progress-ring'
import { Sparkline } from '@/components/dashboard/sparkline'
import { BadgeMedallion } from '@/components/dashboard/badge-medallion'
import {
  academics,
  achievements,
  attendanceTrend,
  clubs,
  currentStudent,
  teacherFeedback,
} from '@/lib/mock-data'

const achievementIcons = [HeartHandshake, Cpu, Medal, Mic]
const clubIcons = [Cpu, Mic, HeartHandshake]

export function StudentHubView() {
  return (
    <div className="flex flex-col gap-6">
      {/* Profile header — glassmorphism */}
      <Card className="overflow-hidden border-0 bg-primary text-primary-foreground shadow-xl">
        <div className="relative">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,oklch(0.62_0.17_250/0.5),transparent_60%)]" />
          <CardContent className="relative flex flex-col gap-5 p-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <Avatar className="size-16 ring-4 ring-primary-foreground/20">
                <AvatarFallback className="bg-accent text-lg font-bold text-accent-foreground">
                  {currentStudent.initials}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="font-heading text-2xl font-bold">{currentStudent.name}</h1>
                <p className="text-sm text-primary-foreground/70">
                  {currentStudent.grade} · {currentStudent.school}
                </p>
                <Badge className="mt-2 gap-1 border-0 bg-accent text-accent-foreground">
                  <Award className="size-3.5" />
                  Kelajak darajasi: {currentStudent.level}
                </Badge>
              </div>
            </div>
            <div className="min-w-56">
              <div className="mb-1.5 flex items-center justify-between text-xs text-primary-foreground/80">
                <span>{currentStudent.xp.toLocaleString()} XP</span>
                <span>{currentStudent.nextLevelXp.toLocaleString()} XP</span>
              </div>
              <Progress
                value={currentStudent.levelProgress}
                className="h-2.5 bg-primary-foreground/20 [&>div]:bg-accent"
              />
              <p className="mt-1.5 text-xs text-primary-foreground/70">
                5-darajagacha {100 - currentStudent.levelProgress}% — Bo'lajak Yetakchi
              </p>
            </div>
          </CardContent>
        </div>
      </Card>

      {/* Section 1 — Academic Portfolio */}
      <section className="flex flex-col gap-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Akademik portfel</h2>
        <div className="grid gap-4 lg:grid-cols-4">
          <Card className="lg:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Umumiy GPA
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="font-heading text-4xl font-bold text-primary">
                {academics.gpa.toFixed(2)}
                <span className="text-lg text-muted-foreground"> / {academics.gpaMax.toFixed(1)}</span>
              </p>
              <Progress value={(academics.gpa / academics.gpaMax) * 100} className="mt-3 h-2 [&>div]:bg-success" />
              <p className="mt-2 text-xs text-success">Eng yaxshi 8% qatorida</p>
            </CardContent>
          </Card>

          <Card className="flex flex-col items-center justify-center py-4">
            <ProgressRing
              value={(academics.ielts.current / 9) * 100}
              label={academics.ielts.current.toFixed(1)}
              sublabel={`Maqsad ${academics.ielts.target.toFixed(1)}`}
              colorClass="text-accent"
            />
            <p className="mt-1 text-sm font-semibold text-foreground">IELTS bali</p>
          </Card>

          <Card className="flex flex-col items-center justify-center py-4">
            <ProgressRing
              value={(academics.sat.current / 1600) * 100}
              label={String(academics.sat.current)}
              sublabel={`Maqsad ${academics.sat.target}`}
              colorClass="text-primary"
            />
            <p className="mt-1 text-sm font-semibold text-foreground">SAT natijasi</p>
          </Card>

          <Card className="lg:col-span-1">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <Trophy className="size-4 text-warning-foreground" />
                Olimpiada sertifikatlari
              </CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-2.5">
              {academics.olympiads.map((o) => (
                <div key={o.id} className="flex items-start gap-2.5 rounded-xl bg-muted/60 p-2.5">
                  <GraduationCap className="mt-0.5 size-4 shrink-0 text-accent" />
                  <div className="leading-tight">
                    <p className="text-xs font-semibold text-foreground">{o.title}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {o.place} · {o.year}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Section 2 — Extracurricular Portfolio */}
      <section className="flex flex-col gap-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Darsdan tashqari portfel</h2>
        <div className="grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Faol to'garaklar</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-3">
              {clubs.map((club, i) => {
                const Icon = clubIcons[i % clubIcons.length]
                return (
                  <div
                    key={club.id}
                    className="group rounded-2xl border border-border bg-card p-4 transition-all hover:-translate-y-1 hover:border-accent/40 hover:shadow-md"
                  >
                    <div className="flex items-center justify-between">
                      <span className="flex size-10 items-center justify-center rounded-xl bg-accent/10 text-accent transition-transform group-hover:scale-110">
                        <Icon className="size-5" />
                      </span>
                      <Badge variant="secondary" className="text-[11px]">
                        {club.sessions} mashg'ulot
                      </Badge>
                    </div>
                    <p className="mt-3 font-heading font-semibold text-foreground">{club.name}</p>
                    <p className="text-xs text-muted-foreground">{club.role}</p>
                  </div>
                )
              })}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <TrendingUp className="size-4 text-success" />
                Davomat dinamikasi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline gap-2">
                <span className="font-heading text-3xl font-bold text-foreground">96%</span>
                <span className="text-xs font-medium text-success">bu chorakda +8%</span>
              </div>
              <Sparkline data={attendanceTrend} className="mt-3" />
              <p className="mt-2 text-xs text-muted-foreground">To'garak ishtirokining oxirgi 10 haftasi</p>
            </CardContent>
          </Card>
        </div>

        <Card className="border-l-4 border-l-accent">
          <CardContent className="flex gap-4 p-5">
            <Quote className="size-8 shrink-0 text-accent/50" />
            <div>
              <p className="text-pretty font-medium italic text-foreground">
                &ldquo;{teacherFeedback.quote}&rdquo;
              </p>
              <p className="mt-2 text-sm font-semibold text-foreground">{teacherFeedback.teacher}</p>
              <p className="text-xs text-muted-foreground">{teacherFeedback.subject}</p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Section 3 — Achievements */}
      <section className="flex flex-col gap-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Kelajak nishonlari</h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {achievements.map((a, i) => (
            <BadgeMedallion
              key={a.id}
              icon={achievementIcons[i % achievementIcons.length]}
              name={a.name}
              desc={a.desc}
              tone={a.tone as 'success' | 'accent' | 'warning' | 'primary'}
            />
          ))}
        </div>
      </section>
    </div>
  )
}
