'use client'

import { useState } from 'react'
import {
  Users,
  AlertTriangle,
  HeartHandshake,
  FileText,
  Download,
  Filter,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { cn } from '@/lib/utils'
import {
  counselorLibrary,
  counselorStats,
  monitoredStudents,
} from '@/lib/mock-data'

const stats = [
  {
    label: 'Jami o\'quvchilar',
    value: counselorStats.totalStudents,
    icon: Users,
    tone: 'bg-primary/10 text-primary',
  },
  {
    label: 'Xavf ostidagi o\'quvchilar',
    value: counselorStats.atRisk,
    icon: AlertTriangle,
    tone: 'bg-warning/20 text-warning-foreground',
    note: '0 ta to\'garak',
  },
  {
    label: 'Mentorlik bog\'lanishlari',
    value: counselorStats.mentorshipMatches,
    icon: HeartHandshake,
    tone: 'bg-success/15 text-success',
  },
]

export function CounselorView() {
  const [onlyAtRisk, setOnlyAtRisk] = useState(false)

  const rows = onlyAtRisk
    ? monitoredStudents.filter((s) => s.clubs === 0)
    : monitoredStudents

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="font-heading text-2xl font-bold text-foreground">Maslahatchi paneli</h1>
        <p className="text-sm text-muted-foreground">
          O'quvchilar faolligini kuzating va xavf ostidagilarga erta yordam bering.
        </p>
      </div>

      {/* Top metrics */}
      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="flex items-center gap-4 p-5">
              <span className={cn('flex size-12 items-center justify-center rounded-2xl', stat.tone)}>
                <stat.icon className="size-6" />
              </span>
              <div>
                <p className="font-heading text-3xl font-bold text-foreground">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                {stat.note && <p className="text-[11px] text-warning-foreground">{stat.note}</p>}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Section 1 — Monitoring table */}
      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-heading text-lg font-semibold text-foreground">Student Monitoring</h2>
          <Button
            variant={onlyAtRisk ? 'default' : 'outline'}
            size="sm"
            onClick={() => setOnlyAtRisk((v) => !v)}
            className={cn('gap-2', onlyAtRisk && 'bg-destructive text-white hover:bg-destructive/90')}
          >
            <Filter className="size-4" data-icon="inline-start" />
            {onlyAtRisk ? 'Showing At-Risk Only' : 'Filter At-Risk (Red)'}
          </Button>
        </div>

        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Student</TableHead>
                  <TableHead>Grade</TableHead>
                  <TableHead>Region</TableHead>
                  <TableHead className="text-right">GPA</TableHead>
                  <TableHead className="text-right">Club Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((student) => {
                  const active = student.clubs > 0
                  return (
                    <TableRow key={student.id} className="transition-colors hover:bg-muted/60">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="size-9">
                            <AvatarFallback className="bg-primary/10 text-xs font-semibold text-primary">
                              {student.initials}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium text-foreground">{student.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{student.grade}</TableCell>
                      <TableCell className="text-muted-foreground">{student.region}</TableCell>
                      <TableCell className="text-right">
                        <span
                          className={cn(
                            'font-semibold',
                            student.gpa >= 3.5
                              ? 'text-success'
                              : student.gpa >= 3.0
                                ? 'text-foreground'
                                : 'text-destructive',
                          )}
                        >
                          {student.gpa.toFixed(2)}
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge
                          className={cn(
                            'border-0',
                            active
                              ? 'bg-success/15 text-success'
                              : 'bg-destructive/15 text-destructive',
                          )}
                        >
                          <span
                            className={cn(
                              'mr-1 inline-block size-1.5 rounded-full',
                              active ? 'bg-success' : 'bg-destructive',
                            )}
                          />
                          {active ? `${student.clubs} active` : 'No clubs'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </section>

      {/* Section 2 — Digital Library */}
      <section className="flex flex-col gap-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Digital Library</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {counselorLibrary.map((res) => (
            <Card key={res.id} className="group transition-all hover:-translate-y-1 hover:shadow-md">
              <CardContent className="flex items-center gap-3 p-4">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <FileText className="size-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-foreground">{res.title}</p>
                  <p className="text-xs text-muted-foreground">{res.type}</p>
                </div>
                <Button size="icon" variant="ghost" className="shrink-0 text-accent" aria-label={`Download ${res.title}`}>
                  <Download className="size-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
