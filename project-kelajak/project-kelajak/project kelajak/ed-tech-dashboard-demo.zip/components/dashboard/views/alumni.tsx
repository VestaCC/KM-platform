import { Crown, GraduationCap, PlayCircle, MessageCircle, Trophy } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { alumniHallOfFame, mentors } from '@/lib/mock-data'

const podiumStyles: Record<number, { ring: string; badge: string; height: string }> = {
  1: { ring: 'ring-warning', badge: 'bg-warning text-warning-foreground', height: 'sm:mt-0' },
  2: { ring: 'ring-muted-foreground/40', badge: 'bg-secondary text-secondary-foreground', height: 'sm:mt-8' },
  3: { ring: 'ring-accent/50', badge: 'bg-accent/15 text-accent', height: 'sm:mt-12' },
}

function initialsOf(name: string) {
  return name
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
}

export function AlumniView() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="font-heading text-2xl font-bold text-foreground">Bitiruvchilar tarmog'i</h1>
        <p className="text-sm text-muted-foreground">
          Bitiruvchilarimiz bilan faxrlaning va dunyoning eng yaxshi universitetlaridagi mentorlar bilan bog'laning.
        </p>
      </div>

      {/* Section 1 — Hall of Fame */}
      <section className="flex flex-col gap-3">
        <h2 className="flex items-center gap-2 font-heading text-lg font-semibold text-foreground">
          <Trophy className="size-5 text-warning-foreground" />
          Shon-sharaf zali
        </h2>
        <Card className="border-0 bg-primary text-primary-foreground">
          <CardContent className="grid items-end gap-4 p-6 sm:grid-cols-3">
            {alumniHallOfFame.map((alum) => {
              const style = podiumStyles[alum.rank]
              return (
                <div
                  key={alum.id}
                  className={cn(
                    'flex flex-col items-center gap-2 rounded-2xl bg-primary-foreground/5 p-5 text-center ring-1 ring-primary-foreground/10',
                    style.height,
                  )}
                >
                  <div className="relative">
                    <Avatar className={cn('size-16 ring-4', style.ring)}>
                      <AvatarFallback className="bg-accent text-base font-bold text-accent-foreground">
                        {initialsOf(alum.name)}
                      </AvatarFallback>
                    </Avatar>
                    {alum.rank === 1 && (
                      <Crown className="absolute -top-3 left-1/2 size-6 -translate-x-1/2 text-warning" />
                    )}
                    <span
                      className={cn(
                        'absolute -bottom-1 left-1/2 flex size-6 -translate-x-1/2 items-center justify-center rounded-full text-xs font-bold ring-2 ring-primary',
                        style.badge,
                      )}
                    >
                      {alum.rank}
                    </span>
                  </div>
                  <div className="mt-2">
                    <p className="font-heading font-semibold">{alum.name}</p>
                    <p className="text-sm text-accent">
                      {alum.university} {alum.year}
                    </p>
                    <p className="text-xs text-primary-foreground/60">{alum.major}</p>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </section>

      {/* Section 2 — Mentorship Hub */}
      <section className="flex flex-col gap-3">
        <h2 className="font-heading text-lg font-semibold text-foreground">Mentorlik markazi</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          {mentors.map((mentor) => (
            <Card key={mentor.id} className="transition-all hover:shadow-md">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <Avatar className="size-12">
                    <AvatarFallback className="bg-accent/15 font-semibold text-accent">
                      {mentor.initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <CardTitle className="text-base">{mentor.name}</CardTitle>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground">
                      <GraduationCap className="size-3.5" />
                      {mentor.university} · {mentor.major}
                    </p>
                  </div>
                  {mentor.available ? (
                    <Badge className="border-0 bg-success/15 text-success">Bo'sh</Badge>
                  ) : (
                    <Badge variant="secondary">Band</Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="flex gap-2">
                <Button size="sm" variant="outline" className="flex-1 gap-1.5">
                  <PlayCircle className="size-4" data-icon="inline-start" />
                  Vebinarni ko'rish
                </Button>
                <Button
                  size="sm"
                  className="flex-1 gap-1.5 bg-accent text-accent-foreground hover:bg-accent/90"
                  disabled={!mentor.available}
                >
                  <MessageCircle className="size-4" data-icon="inline-start" />
                  Yopiq chatga qo'shilish
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  )
}
