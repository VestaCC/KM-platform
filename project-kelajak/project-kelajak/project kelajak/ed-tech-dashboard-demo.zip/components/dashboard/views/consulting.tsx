'use client'

import {
  Sparkles,
  CheckCircle2,
  Circle,
  FileText,
  BookOpen,
  ListChecks,
  GraduationCap,
  UserPlus,
  Download,
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import { guides, roadmap } from '@/lib/mock-data'

const guideIcons = [FileText, BookOpen, FileText, GraduationCap, ListChecks, BookOpen]

const statusStyles: Record<string, string> = {
  done: 'bg-success text-success-foreground',
  active: 'bg-accent text-accent-foreground',
  upcoming: 'bg-muted text-muted-foreground',
}

export function ConsultingView() {
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="font-heading text-2xl font-bold text-foreground">Kelajak Konsalting</h1>
        <p className="text-sm text-muted-foreground">
          9-sinfdan jahon darajasidagi universitetgacha bo'lgan shaxsiy yo'lingiz.
        </p>
      </div>

      {/* Section 1 — Roadmap Generator */}
      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-heading text-lg font-semibold text-foreground">Yo'l xaritasi generatori</h2>
          <Button className="gap-2 bg-accent text-accent-foreground hover:bg-accent/90">
            <Sparkles className="size-4" data-icon="inline-start" />
            AI yo'l xaritasini yaratish
          </Button>
        </div>

        <Card>
          <CardContent className="p-6">
            <ol className="relative flex flex-col gap-8 border-l-2 border-dashed border-border pl-8">
              {roadmap.map((stage) => (
                <li key={stage.id} className="relative">
                  <span
                    className={cn(
                      'absolute -left-[42px] flex size-7 items-center justify-center rounded-full ring-4 ring-background',
                      statusStyles[stage.status],
                    )}
                  >
                    {stage.status === 'done' ? (
                      <CheckCircle2 className="size-4" />
                    ) : (
                      <span className="text-xs font-bold">{stage.id}</span>
                    )}
                  </span>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-heading text-base font-semibold text-foreground">{stage.grade}</h3>
                    {stage.status === 'active' && (
                      <Badge className="border-0 bg-accent/15 text-accent">Jarayonda</Badge>
                    )}
                    {stage.status === 'done' && (
                      <Badge className="border-0 bg-success/15 text-success">Yakunlangan</Badge>
                    )}
                  </div>
                  <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                    {stage.items.map((item) => (
                      <li
                        key={item.title}
                        className="flex items-center gap-2.5 rounded-xl border border-border bg-card p-3 transition-colors hover:border-accent/40"
                      >
                        {item.done ? (
                          <CheckCircle2 className="size-4 shrink-0 text-success" />
                        ) : (
                          <Circle className="size-4 shrink-0 text-muted-foreground" />
                        )}
                        <span
                          className={cn(
                            'text-sm',
                            item.done ? 'text-muted-foreground line-through' : 'text-foreground',
                          )}
                        >
                          {item.title}
                        </span>
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      </section>

      {/* Section 2 — International Guide */}
      <section className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-heading text-lg font-semibold text-foreground">Xalqaro qo'llanma</h2>
          <Button variant="outline" className="gap-2">
            <UserPlus className="size-4" data-icon="inline-start" />
            Mentor bilan bog'lanish
          </Button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {guides.map((guide, i) => {
            const Icon = guideIcons[i % guideIcons.length]
            return (
              <Card
                key={guide.id}
                className="group cursor-pointer transition-all hover:-translate-y-1 hover:shadow-lg"
              >
                <CardContent className="flex flex-col gap-3 p-5">
                  <div className="flex items-center justify-between">
                    <span className="flex size-11 items-center justify-center rounded-xl bg-accent/10 text-accent transition-transform group-hover:scale-110">
                      <Icon className="size-5" />
                    </span>
                    <Badge variant="secondary" className="text-[11px]">
                      {guide.type}
                    </Badge>
                  </div>
                  <p className="font-heading font-semibold leading-snug text-foreground">{guide.title}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{guide.reads} o'qildi</span>
                    <span className="flex items-center gap-1 font-medium text-accent">
                      <Download className="size-3.5" />
                      Ochish
                    </span>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </section>
    </div>
  )
}
