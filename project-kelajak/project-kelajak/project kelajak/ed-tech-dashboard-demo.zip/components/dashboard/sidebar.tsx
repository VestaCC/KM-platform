'use client'

import {
  GraduationCap,
  Compass,
  Building2,
  Users,
  LayoutDashboard,
  Sparkles,
} from 'lucide-react'
import { cn } from '@/lib/utils'

export type ViewKey = 'hub' | 'consulting' | 'market' | 'alumni' | 'counselor'

export const navItems: {
  key: ViewKey
  label: string
  module: string
  icon: typeof GraduationCap
}[] = [
  { key: 'hub', label: 'O\'quvchi sahifasi', module: 'A Modul', icon: GraduationCap },
  { key: 'consulting', label: 'Kelajak Konsalting', module: 'B Modul', icon: Compass },
  { key: 'market', label: 'Mehnat va Texnikumlar', module: 'C Modul', icon: Building2 },
  { key: 'alumni', label: 'Bitiruvchilar tarmog\'i', module: 'D Modul', icon: Users },
  { key: 'counselor', label: 'Maslahatchi paneli', module: 'E Modul', icon: LayoutDashboard },
]

export function Sidebar({
  active,
  onChange,
}: {
  active: ViewKey
  onChange: (key: ViewKey) => void
}) {
  return (
    <aside className="flex w-64 shrink-0 flex-col gap-6 bg-sidebar p-4 text-sidebar-foreground max-md:hidden">
      <div className="flex items-center gap-3 px-2 pt-2">
        <div className="flex size-10 items-center justify-center rounded-2xl bg-sidebar-primary text-sidebar-primary-foreground">
          <Sparkles className="size-5" />
        </div>
        <div className="leading-tight">
          <p className="font-heading text-lg font-bold text-sidebar-accent-foreground">
            Kelajak
          </p>
          <p className="text-xs text-sidebar-foreground/70">Centers</p>
        </div>
      </div>

      <nav className="flex flex-col gap-1">
        {navItems.map((item) => {
          const isActive = item.key === active
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onChange(item.key)}
              aria-current={isActive ? 'page' : undefined}
              className={cn(
                'group flex items-center gap-3 rounded-2xl px-3 py-3 text-left transition-all',
                isActive
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-lg'
                  : 'text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
              )}
            >
              <item.icon className="size-5 shrink-0" />
              <span className="flex flex-col">
                <span className="text-sm font-semibold">{item.label}</span>
                <span
                  className={cn(
                    'text-[11px]',
                    isActive ? 'text-sidebar-primary-foreground/70' : 'text-sidebar-foreground/50',
                  )}
                >
                  {item.module}
                </span>
              </span>
            </button>
          )
        })}
      </nav>

      <div className="mt-auto rounded-2xl bg-sidebar-accent/60 p-4 backdrop-blur">
        <p className="font-heading text-sm font-semibold text-sidebar-accent-foreground">
          Kelajakni quryapmiz
        </p>
        <p className="mt-1 text-xs text-sidebar-foreground/70">
          O'zbekiston bo'ylab 248 o'quvchini jahon darajasidagi ta'limga yo'naltiramiz.
        </p>
      </div>
    </aside>
  )
}

export function MobileNav({
  active,
  onChange,
}: {
  active: ViewKey
  onChange: (key: ViewKey) => void
}) {
  return (
    <nav className="sticky top-0 z-20 flex gap-2 overflow-x-auto border-b border-border bg-sidebar px-3 py-2 md:hidden">
      {navItems.map((item) => {
        const isActive = item.key === active
        return (
          <button
            key={item.key}
            type="button"
            onClick={() => onChange(item.key)}
            className={cn(
              'flex shrink-0 items-center gap-2 rounded-full px-3 py-2 text-xs font-semibold transition-colors',
              isActive
                ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                : 'text-sidebar-foreground/70',
            )}
          >
            <item.icon className="size-4" />
            {item.label}
          </button>
        )
      })}
    </nav>
  )
}
