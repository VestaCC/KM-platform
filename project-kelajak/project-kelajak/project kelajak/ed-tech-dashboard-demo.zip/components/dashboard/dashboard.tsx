'use client'

import { useState } from 'react'
import { Bell, Search } from 'lucide-react'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { MobileNav, Sidebar, navItems, type ViewKey } from '@/components/dashboard/sidebar'
import { StudentHubView } from '@/components/dashboard/views/student-hub'
import { ConsultingView } from '@/components/dashboard/views/consulting'
import { LaborMarketView } from '@/components/dashboard/views/labor-market'
import { AlumniView } from '@/components/dashboard/views/alumni'
import { CounselorView } from '@/components/dashboard/views/counselor'
import { currentStudent } from '@/lib/mock-data'

const views: Record<ViewKey, React.ReactNode> = {
  hub: <StudentHubView />,
  consulting: <ConsultingView />,
  market: <LaborMarketView />,
  alumni: <AlumniView />,
  counselor: <CounselorView />,
}

export function Dashboard() {
  const [active, setActive] = useState<ViewKey>('hub')
  const current = navItems.find((n) => n.key === active)

  return (
    <div className="flex min-h-svh">
      <Sidebar active={active} onChange={setActive} />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Glassmorphism top bar */}
        <header className="sticky top-0 z-10 flex items-center justify-between gap-4 border-b border-border bg-background/70 px-4 py-3 backdrop-blur-md sm:px-6">
          <div className="min-w-0">
            <p className="text-xs font-medium text-muted-foreground">{current?.module}</p>
            <h2 className="truncate font-heading text-lg font-bold text-foreground">{current?.label}</h2>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-sm text-muted-foreground sm:flex">
              <Search className="size-4" />
              <span>O'quvchi, maktab qidirish…</span>
            </div>
            <button
              type="button"
              className="relative flex size-10 items-center justify-center rounded-full border border-border bg-card text-muted-foreground transition-colors hover:text-foreground"
              aria-label="Bildirishnomalar"
            >
              <Bell className="size-4.5" />
              <span className="absolute right-2.5 top-2.5 size-2 rounded-full bg-accent ring-2 ring-card" />
            </button>
            <Avatar className="size-10">
              <AvatarFallback className="bg-primary text-sm font-bold text-primary-foreground">
                {currentStudent.initials}
              </AvatarFallback>
            </Avatar>
          </div>
        </header>

        <MobileNav active={active} onChange={setActive} />

        <main className="flex-1 p-4 sm:p-6">{views[active]}</main>
      </div>
    </div>
  )
}
